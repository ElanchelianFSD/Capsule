import { TestBed, async, ComponentFixture, inject  } from '@angular/core/testing';
import { ViewTaskComponent } from './view-task.component';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing' 
import { Component, NgModule, OnInit, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule,ReactiveFormsModule, FormGroup, FormBuilder, Validators } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { TaskServiceService } from '../Services/task-service.service';
import { FilterPipe } from '../pipes/filter.pipe';
import { PageService } from '../Services/page-service';
import { AlertsModule } from 'angular-alert-module';
import Swal from 'sweetalert2';
import { Observable, of } from 'rxjs';
import { AppComponent } from '../app.component';

describe('ViewTaskComponent', () => {
  let component: ViewTaskComponent;
  let fixture: ComponentFixture<ViewTaskComponent>;
  let appcomponent: AppComponent;  
  var pagedItems: any = [];
const parentTaskDetail: any = [
    {
      "ParentTask": "Parent A",
      "ParentId": 1
     
    },
    {
      "ParentTask": "Parent B",
      "ParentId": 2
     
    },
    {
     "ParentTask": "Parent C",
      "ParentId": 3
     
    }
  ];
  

  const taskDetail: any = [
    {
      "TaskId": 0,
      "ParentTask": 2,
      "Task": "Test A",
      "StartDate": "09/19/2018",
      "EndDate": "09/19/2018",
      "Priority": 10
    },
    {
      "TaskId": 0,
      "ParentTask": 2,
      "Task": "Test B",
      "StartDate": "09/17/2018",
      "EndDate": "09/18/2018",
      "Priority": 20,
      "IsActive":1
    },
    {
      "TaskId": 0,
      "ParentTask": 2,
      "Task": "Test C",
      "StartDate": "09/18/2018",
      "EndDate": "09/20/2018",
      "Priority": 30
    }
  ];


   let mockService = {
    getParentTask(): Observable<any> {
      return of(parentTaskDetail);
    },

    getTaskManager(): Observable<any> {
      return of(taskDetail);
    },

    submitTask(task): Observable<any> {
      taskDetail.unshift(task);
      return of(task);
    },

    updateEndTask(task): Observable<any> {
      let idx = taskDetail.findIndex(x => x.TaskId == task.TaskId);
      if (idx !== -1) {
        taskDetail[idx] = task;
      }
      return of(task);
    },
  }


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        ViewTaskComponent, FilterPipe  ,AppComponent     
      ],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [HttpClientModule, RouterTestingModule, BrowserAnimationsModule, FormsModule, AlertsModule,ReactiveFormsModule],
      providers: [{ provide: TaskServiceService, useValue: mockService }, PageService,AppComponent]
    }).compileComponents();
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(ViewTaskComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();    
  });
  
  //  it('should be get', inject([TaskServiceService], (service: TaskServiceService) => {
  //   mockService.getParentTask().subscribe(data => {component.parentTaskList = data;});
  //   mockService.getTaskManager().subscribe(data => {pagedItems = data;});
  //   fixture.detectChanges();
  //   expect(service).toBeTruthy();
  // }));
});
