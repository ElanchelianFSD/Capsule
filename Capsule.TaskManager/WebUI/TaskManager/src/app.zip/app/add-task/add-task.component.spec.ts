
import { TestBed, async, ComponentFixture, inject  } from '@angular/core/testing';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterTestingModule } from '@angular/router/testing'
import { AddTaskComponent } from './add-task.component';
import { Component, NgModule, OnInit, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule,ReactiveFormsModule, FormGroup, FormBuilder, Validators,FormControl } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import { TaskServiceService } from '../Services/task-service.service';
import { FilterPipe } from '../pipes/filter.pipe';
import { PageService } from '../Services/page-service';
import { AlertsModule } from 'angular-alert-module';
import {  AppComponent } from '../app.component';
import { Observable, of } from 'rxjs';
describe('AddTaskComponent', () => {
  let addComponent: AddTaskComponent;
  let appComponent: AppComponent;
  let fixture: ComponentFixture<AddTaskComponent>;
 
  // var myForm = new FormGroup({
  //      TaskId: new FormControl(),
  //      Task: new FormControl(),
  //      Priority: new FormControl(),
  //      ParentId: new FormControl(),
  //      ParentTask: new FormControl(),
  //      StartDate: new FormControl(),
  //      EndDate: new FormControl(),
  //      IsActive: new FormControl()
  //   });
  
 

  const parentTaskDetails: any = [
    {
      "ParentTask": "Parent A",
      "ParentId": 1
     
    },
    {
      "ParentTask": "Parent B",
      "ParentId": 2
     
    },
    {
     "ParentTask": "Parent C",
      "ParentId": 3
     
    }
  ];


   let mockService = {
    getParentTask(): Observable<any> {
      return of(appComponent.parentTaskList);
    }   
  }

beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AddTaskComponent],
      imports: [FormsModule, ReactiveFormsModule]
    });
  });
 
  beforeEach(inject([AddTaskComponent], (addtask: AddTaskComponent) => {
    addComponent = addtask;
  }));


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddTaskComponent, FilterPipe ],
      schemas: [NO_ERRORS_SCHEMA],
      imports: [HttpClientModule, RouterTestingModule, BrowserAnimationsModule, FormsModule, AlertsModule,ReactiveFormsModule],
      providers: [{ provide: TaskServiceService,FormBuilder,FormGroup , useValue: mockService }, PageService,AppComponent]
    })
    .compileComponents();
  }));
 
   
  // it('should create', () => {     
  //   expect(addComponent).toBeTruthy();    
  // });

  // it('should be get', inject([TaskServiceService], (service: TaskServiceService) => {
  //   mockService.getParentTask().subscribe(parentTaskDetails); 
  //   fixture.detectChanges();
  //   expect(service).toBeTruthy();
  // }));
  //  it('should be get', inject([TaskServiceService], (service: TaskServiceService) => {
  //   mockService.getParentTask().subscribe(data => {appComponent.parentTaskList = data;}); 
  //   fixture.detectChanges();
  //   expect(service).toBeTruthy();
  // }));  
});
